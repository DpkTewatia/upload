<?php

return require __DIR__.'/vendor/autoload.php';
