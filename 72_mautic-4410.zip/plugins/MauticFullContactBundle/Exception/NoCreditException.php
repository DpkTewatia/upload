<?php

namespace MauticPlugin\MauticFullContactBundle\Exception;

class NoCreditException extends BaseException
{
}
