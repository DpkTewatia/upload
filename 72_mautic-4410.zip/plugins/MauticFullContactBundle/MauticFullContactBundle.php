<?php

namespace MauticPlugin\MauticFullContactBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

class MauticFullContactBundle extends PluginBundleBase
{
}
