<?php

namespace MauticPlugin\MauticSocialBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

/**
 * Class MauticSocialBundle.
 */
class MauticSocialBundle extends PluginBundleBase
{
}
