<?php

namespace MauticPlugin\MauticSocialBundle\Entity;

use Mautic\CoreBundle\Entity\CommonRepository;

class TweetStatRepository extends CommonRepository
{
}
