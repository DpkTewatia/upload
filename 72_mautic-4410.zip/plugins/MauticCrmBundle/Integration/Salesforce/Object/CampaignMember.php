<?php

namespace MauticPlugin\MauticCrmBundle\Integration\Salesforce\Object;

class CampaignMember
{
    const OBJECT = 'CampaignMember';
}
