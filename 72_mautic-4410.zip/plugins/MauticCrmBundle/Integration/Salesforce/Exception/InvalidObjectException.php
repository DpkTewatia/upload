<?php

namespace MauticPlugin\MauticCrmBundle\Integration\Salesforce\Exception;

class InvalidObjectException extends \InvalidArgumentException
{
}
