<?php

namespace MauticPlugin\MauticCrmBundle\Api\Salesforce\Exception;

class RetryRequestException extends \Exception
{
}
