<?php

namespace MauticPlugin\MauticCrmBundle\Api\Zoho\Exception;

class MatchingKeyNotFoundException extends \Exception
{
}
