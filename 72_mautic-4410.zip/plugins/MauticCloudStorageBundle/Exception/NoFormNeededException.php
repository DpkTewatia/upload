<?php

namespace MauticPlugin\MauticCloudStorageBundle\Exception;

class NoFormNeededException extends \Exception
{
}
