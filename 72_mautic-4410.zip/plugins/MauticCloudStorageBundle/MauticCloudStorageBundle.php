<?php

namespace MauticPlugin\MauticCloudStorageBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

class MauticCloudStorageBundle extends PluginBundleBase
{
}
