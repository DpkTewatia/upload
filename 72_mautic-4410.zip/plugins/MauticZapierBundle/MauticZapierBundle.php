<?php

namespace MauticPlugin\MauticZapierBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

class MauticZapierBundle extends PluginBundleBase
{
}
