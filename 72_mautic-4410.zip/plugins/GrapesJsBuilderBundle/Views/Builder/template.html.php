<?php

    echo json_encode([
        'templateHtml' => $templateHtml,
        'templateMjml' => $templateMjml,
    ]);
