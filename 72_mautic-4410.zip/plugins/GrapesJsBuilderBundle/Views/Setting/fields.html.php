<div class="row hide">
    <div class="form-group col-xs-12 ">
        <div class="input-group">
            <textarea id="grapesjsbuilder_customMjml" class="form-control builder-mjml" name="grapesjsbuilder[customMjml]"><?php echo $customMjml; ?></textarea>
        </div>
    </div>
</div>
