<?php

namespace MauticPlugin\MauticGmailBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

/**
 * Class MauticGmailBundle.
 */
class MauticGmailBundle extends PluginBundleBase
{
}
