<?php

namespace MauticPlugin\MauticOutlookBundle;

use Mautic\PluginBundle\Bundle\PluginBundleBase;

/**
 * Class MauticOutlookBundle.
 */
class MauticOutlookBundle extends PluginBundleBase
{
}
