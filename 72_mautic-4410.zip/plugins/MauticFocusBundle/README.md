# Mautic bundle for Focus Items plugin

## This plugin is managed centrally in https://github.com/mautic/mautic/blob/head/plugins/MauticFocusBundle and this is a read-only mirror repository.

**📣 Please make PRs and issues against Mautic Core, not here!**