# Mautic bundle for Clearbit plugin

## This plugin is managed centrally in https://github.com/mautic/mautic/blob/head/plugins/MauticClearbitBundle and this is a read-only mirror repository.

**📣 Please make PRs and issues against Mautic Core, not here!**